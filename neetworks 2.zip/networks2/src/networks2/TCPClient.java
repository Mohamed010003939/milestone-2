package networks2;

import java.io.*;
import java.net.*;

class TCPClient {

	public static void main(String argv[]) throws Exception {
		String sentence;
		String modifiedSentene;
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		sentence = inFromUser.readLine();
		if (sentence.equals("CONNECT")) {
			System.out.println("successfully connected");
			while (true) {
				Socket clientSocket = new Socket("127.0.0.1", 6789);
				DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
				BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				BufferedReader inFromUser2 = new BufferedReader(new InputStreamReader(System.in));
				sentence = inFromUser2.readLine();
				if (sentence.equals("END")) {
					clientSocket.close();
					return;

				} else {
					outToServer.writeBytes(sentence + '\n');
					outToServer.flush();
					modifiedSentene=inFromServer.readLine();
					System.out.println("server:" + sentence);
				}

			}
		}

	}
}