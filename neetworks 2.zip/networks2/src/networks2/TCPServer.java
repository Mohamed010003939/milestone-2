package networks2;

import java.io.*;
import java.net.*;

class TCPServer {

	public static void main(String argv[]) throws Exception {
		String clientSentence;
		String capitalizedSentence;

		ServerSocket welcomeSocket = new ServerSocket(6789);

		while (true) {
			Socket connectionSocket = welcomeSocket.accept();
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			clientSentence = inFromClient.readLine();
			if (clientSentence != null) {
				System.out.println("recived" + clientSentence);
				BufferedReader inFromServer = new BufferedReader(new InputStreamReader(System.in));
				capitalizedSentence = inFromServer.readLine();
				outToClient.writeBytes(capitalizedSentence +'\n');
				outToClient.flush();

			}
		}
	}
}